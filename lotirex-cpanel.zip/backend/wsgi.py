"""Passenger entry point for shared hosting; cron owns result synchronization.

a2wsgi dispatches HTTP requests without ASGI lifespan events, so initialize the
database schema explicitly during application creation. Initialization is
idempotent and preserves the installed SQLite results snapshot.
"""
import asyncio
import os

from a2wsgi import ASGIMiddleware


TASK_KEY = "lotirex.asgi_task"


class PassengerApplication(ASGIMiddleware):
    """Retain a2wsgi's bridge and clean up disconnected streaming requests."""

    def __init__(self, app, **kwargs):
        async def dispatch(scope, receive, send):
            environ = scope["wsgi_environ"]
            environ[TASK_KEY] = asyncio.current_task()
            try:
                await app(scope, receive, send)
            finally:
                environ.pop(TASK_KEY, None)

        super().__init__(dispatch, **kwargs)

    def __call__(self, environ, start_response):
        response = super().__call__(environ, start_response)
        try:
            yield from response
        finally:
            response.close()
            task = environ.get(TASK_KEY)
            if task is not None:
                # a2wsgi waits for application completion after a fully drained
                # response. Closing its iterator early skips that path; cancel
                # the tracked ASGI task so its file handles are still released.
                async def cancel_request():
                    task.cancel()
                    try:
                        await task
                    except asyncio.CancelledError:
                        pass

                asyncio.run_coroutine_threadsafe(cancel_request(), self.loop).result(timeout=self.wait_time)


def create_application(*, loop: asyncio.AbstractEventLoop | None = None) -> PassengerApplication:
    # Enforce this before importing the ASGI application, even if the hosting
    # account inherited the development scheduler setting.
    os.environ["LOTIREX_SCHEDULER"] = "0"
    from . import sync
    from .app import app
    from .deployment import ensure_database

    ensure_database()
    sync.initialize()
    return PassengerApplication(app, wait_time=10, loop=loop)
